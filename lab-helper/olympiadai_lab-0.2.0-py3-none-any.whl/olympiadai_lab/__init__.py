"""olympiadai-lab — local JupyterLab runner for OlympiadAI practice tasks."""

__version__ = "0.2.0"
