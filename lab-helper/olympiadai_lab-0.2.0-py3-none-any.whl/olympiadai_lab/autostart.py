"""`autostart on|off` — register `olympiadai-lab up` to run at login.

macOS:   ~/Library/LaunchAgents/ai.olympiad.lab.plist (launchd user agent)
Windows: schtasks /create /sc onlogon /tn OlympiadAILab
Linux:   ~/.config/systemd/user/olympiadai-lab.service (systemd user unit)

The registration is the only thing written outside the work directory.
"""

from __future__ import annotations

import shutil
import subprocess
import sys
from pathlib import Path

TASK_NAME = "OlympiadAILab"


def _command() -> list[str]:
    """Invoke via the installed entry point; fall back to `python -m`."""
    exe = shutil.which("olympiadai-lab")
    return [exe] if exe else [sys.executable, "-m", "olympiadai_lab"]


def _plist_path() -> Path:
    return Path.home() / "Library" / "LaunchAgents" / "ai.olympiad.lab.plist"


def _unit_path() -> Path:
    return Path.home() / ".config" / "systemd" / "user" / "olympiadai-lab.service"


def _plist(command: list[str]) -> str:
    args = "".join(f"        <string>{part}</string>\n" for part in [*command, "up", "--no-browser"])
    return f"""<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
  <dict>
    <key>Label</key><string>ai.olympiad.lab</string>
    <key>ProgramArguments</key>
    <array>
{args}    </array>
    <key>RunAtLoad</key><true/>
    <key>StandardOutPath</key><string>/dev/null</string>
    <key>StandardErrorPath</key><string>/dev/null</string>
  </dict>
</plist>
"""


def _unit(command: list[str]) -> str:
    return f"""[Unit]
Description=OlympiadAI local JupyterLab

[Service]
Type=simple
ExecStart={' '.join(command)} up --no-browser
Restart=on-failure

[Install]
WantedBy=default.target
"""


def enable() -> Path | str:
    command = _command()
    if sys.platform == "darwin":
        path = _plist_path()
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(_plist(command), encoding="utf-8")
        subprocess.run(["launchctl", "load", str(path)], capture_output=True)
        return path
    if sys.platform == "win32":
        subprocess.run(
            ["schtasks", "/create", "/tn", TASK_NAME, "/sc", "onlogon", "/f",
             "/tr", " ".join([*command, "up", "--no-browser"])],
            check=True, capture_output=True,
        )
        return TASK_NAME
    path = _unit_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(_unit(command), encoding="utf-8")
    subprocess.run(["systemctl", "--user", "daemon-reload"], capture_output=True)
    subprocess.run(["systemctl", "--user", "enable", "--now", "olympiadai-lab.service"], capture_output=True)
    return path


def disable() -> bool:
    if sys.platform == "darwin":
        path = _plist_path()
        if path.exists():
            subprocess.run(["launchctl", "unload", str(path)], capture_output=True)
            path.unlink()
            return True
        return False
    if sys.platform == "win32":
        result = subprocess.run(["schtasks", "/delete", "/tn", TASK_NAME, "/f"], capture_output=True)
        return result.returncode == 0
    path = _unit_path()
    if path.exists():
        subprocess.run(["systemctl", "--user", "disable", "--now", "olympiadai-lab.service"], capture_output=True)
        path.unlink()
        return True
    return False
