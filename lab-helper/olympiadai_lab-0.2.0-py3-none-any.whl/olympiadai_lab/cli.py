"""olympiadai-lab — the one-time local runtime for OlympiadAI practice.

Commands:
  up        create the venv (once), start JupyterLab on 127.0.0.1, pair the LMS
  down      stop the local server
  status    show port, pid, workdir and whether the server answers
  doctor    diagnose environment problems (python, disk, port, firewall)
  autostart register/remove launch-at-login (phase 3)
  open      fetch a notebook into the work dir and print its lab URL
"""

from __future__ import annotations

import argparse
import json
import os
import shutil
import sys
import webbrowser
from pathlib import Path

from . import __version__, core, notebooks, server

DEFAULT_LMS = "http://localhost:3000"


def parse_lms(value: str) -> tuple[str, str]:
    """Split the platform address into (origin, page URL).

    Accepts a bare origin (``https://lms.example``) or a full page URL
    (``http://127.0.0.1:3000/showcase/``). Jupyter's CORS/frame-ancestors
    need the origin only; the pairing link must open the actual page.
    """
    from urllib.parse import urlsplit

    raw = value.strip()
    parts = urlsplit(raw if "://" in raw else "http://" + raw)
    if parts.scheme not in ("http", "https") or not parts.netloc:
        raise SystemExit(f"Некорректный адрес платформы: {value!r}")
    origin = f"{parts.scheme}://{parts.netloc}"
    path = parts.path or "/"
    if not path.endswith("/") and "." not in path.rsplit("/", 1)[-1]:
        path += "/"
    return origin, origin + path


def cmd_up(args: argparse.Namespace) -> int:
    config = core.load_config()
    # No address given (autostart at login, a bare `up`): keep the one the
    # student paired with instead of falling back to the development default.
    lms_origin, lms_url = parse_lms(args.lms_origin or config.get("lmsUrl") or DEFAULT_LMS)
    token = core.ensure_token(config)
    port = config.get("port", args.port)

    already = server.running_pid(config)
    # CORS, frame-ancestors and the cookie policy are baked into the running
    # process — a different platform address needs a restart, not a reuse.
    same_origin = config.get("lmsOrigin") == lms_origin
    if already and same_origin and server.api_status(config.get("port")):
        port = config["port"]
        print(f"JupyterLab уже запущен: http://127.0.0.1:{port}/ (pid {already})")
    else:
        if already or (config.get("port") and server.api_status(config["port"])):
            print("Перезапускаю для нового адреса платформы…" if already and not same_origin
                  else "Останавливаю предыдущий экземпляр…")
            server.stop(config)
            server.wait_stopped(config.get("port"))
        port = server.find_port(config.get("port") or args.port)
        print("Готовлю окружение (первый запуск может занять несколько минут)…", flush=True)
        server.ensure_venv()
        pid = server.start(port, token, lms_origin)
        if not server.wait_ready(port):
            print(f"Сервер не ответил за 60 с — смотрите лог: {core.logs_dir() / f'jupyter-{port}.log'}")
            return 1
        config["pid"] = pid
        print(f"JupyterLab запущен: http://127.0.0.1:{port}/ (pid {pid})")

    config.update({"port": port, "lmsOrigin": lms_origin, "lmsUrl": lms_url})
    core.save_config(config)

    pair_url = f"{lms_url}#lab={port}:{token}"
    print(f"Папка с ноутбуками: {core.workdir()}")
    print(f"Откройте платформу для подключения: {pair_url}")
    if not args.no_browser:
        webbrowser.open(pair_url)
    return 0


def cmd_down(_args: argparse.Namespace) -> int:
    config = core.load_config()
    if server.stop(config):
        config.pop("pid", None)
        core.save_config(config)
        print("Сервер остановлен.")
        return 0
    print("Сервер не был запущен.")
    return 0


def cmd_status(_args: argparse.Namespace) -> int:
    config = core.load_config()
    port = config.get("port")
    pid = server.running_pid(config)
    print(f"Папка:        {core.workdir()}")
    print(f"Порт:         {port if port else '—'}")
    print(f"PID:          {pid if pid else '—'}")
    answering = server.api_status(port) if port else False
    print(f"/api/status:  {'отвечает' if answering else 'не отвечает'}")
    return 0 if answering else 1


def cmd_doctor(_args: argparse.Namespace) -> int:
    ok = True
    version = sys.version_info
    print(f"Python:       {version.major}.{version.minor}.{version.micro} ({sys.executable})")
    if version < (3, 10):
        print("  ✗ нужен Python ≥ 3.10"); ok = False
    else:
        print("  ✓ версия подходит")
    usage = shutil.disk_usage(str(Path.home()))
    free_gb = usage.free / 2**30
    print(f"Диск:         {free_gb:.1f} ГБ свободно")
    if free_gb < 3:
        print("  ✗ нужно минимум ~3 ГБ под окружение и библиотеки"); ok = False
    else:
        print("  ✓ достаточно")
    try:
        port = server.find_port(core.DEFAULT_PORT)
        print(f"Порт:         {port} свободен (диапазон {core.DEFAULT_PORT}–{core.PORT_CEILING})")
    except SystemExit:
        print(f"  ✗ все порты {core.DEFAULT_PORT}–{core.PORT_CEILING} заняты"); ok = False
    config = core.load_config()
    port = config.get("port")
    print(f"Сервер:       {'отвечает на ' + str(port) if port and server.api_status(port) else 'не запущен'}")
    print("Firewall:     сервер слушает только 127.0.0.1 — внешних разрешений не нужно.")
    return 0 if ok else 1


def cmd_open(args: argparse.Namespace) -> int:
    core.ensure_dirs()
    config = core.load_config()
    url = notebooks.open_notebook(args.url, config)
    print(url)
    if not args.no_browser:
        webbrowser.open(url)
    return 0


def cmd_autostart(args: argparse.Namespace) -> int:
    from . import autostart

    if args.action == "on":
        path = autostart.enable()
        print(f"Автозапуск включён: {path}")
    else:
        removed = autostart.disable()
        print("Автозапуск выключен." if removed else "Автозапуск не был настроен.")
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="olympiadai-lab", description=__doc__.splitlines()[1] if __doc__ else None)
    parser.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    sub = parser.add_subparsers(dest="command", required=True)

    up = sub.add_parser("up", help="запустить локальный JupyterLab")
    up.add_argument("--port", type=int, default=core.DEFAULT_PORT)
    up.add_argument("--lms-origin", default=os.environ.get("OLYMPIADAI_LMS_ORIGIN"),
                    help="адрес платформы — origin или полный URL страницы (например https://site/ или http://127.0.0.1:3000/showcase/)")
    up.add_argument("--no-browser", action="store_true", help="не открывать браузер")
    up.set_defaults(func=cmd_up)

    down = sub.add_parser("down", help="остановить сервер")
    down.set_defaults(func=cmd_down)

    status = sub.add_parser("status", help="показать состояние")
    status.set_defaults(func=cmd_status)

    doctor = sub.add_parser("doctor", help="диагностика окружения")
    doctor.set_defaults(func=cmd_doctor)

    auto = sub.add_parser("autostart", help="автозапуск при входе в систему")
    auto.add_argument("action", choices=["on", "off"])
    auto.set_defaults(func=cmd_autostart)

    openp = sub.add_parser("open", help="загрузить ноутбук задания и открыть его в lab")
    openp.add_argument("url", help="URL вида https://<lms>/api/curriculum/materials/<hash>/<name>.ipynb/content")
    openp.add_argument("--no-browser", action="store_true")
    openp.set_defaults(func=cmd_open)

    return parser


def main(argv: list[str] | None = None) -> int:
    # Windows consoles default to charmap — force UTF-8 so Cyrillic (and the
    # ✓/✗ marks in doctor) never crash; `replace` keeps old code pages safe.
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except (AttributeError, ValueError):
            pass
    args = build_parser().parse_args(argv)
    try:
        return args.func(args)
    except KeyboardInterrupt:
        return 130
    except SystemExit:
        raise
    except Exception as error:  # noqa: BLE001 — CLI boundary: report, exit non-zero
        print(f"Ошибка: {error}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
