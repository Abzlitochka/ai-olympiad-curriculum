"""Paths, config and the managed venv — shared by every CLI command.

Layout under the student's work directory (default ``~/Documents/OlympiadAI``,
override with ``OLYMPIADAI_HOME``)::

    OlympiadAI/
      .olympiadai/
        config.json      # token, port, pid — mode 600
        venv/            # managed Python env (jupyterlab, numpy, torch, …)
        logs/            # jupyter server logs
      <lesson-slug>/
        <name>.ipynb     # practice notebooks live here
"""

from __future__ import annotations

import json
import os
import secrets
import stat
import sys
from pathlib import Path

APP_NAME = "olympiadai-lab"
DEFAULT_PORT = 8888
PORT_CEILING = 8899

BASE_PACKAGES = ["jupyterlab", "numpy", "pandas", "matplotlib", "scikit-learn", "scipy"]
TORCH_INDEX = "https://download.pytorch.org/whl/cpu"


def workdir() -> Path:
    override = os.environ.get("OLYMPIADAI_HOME")
    if override:
        return Path(override).expanduser()
    return Path.home() / "Documents" / "OlympiadAI"


def meta_dir() -> Path:
    return workdir() / ".olympiadai"


def config_path() -> Path:
    return meta_dir() / "config.json"


def venv_dir() -> Path:
    return meta_dir() / "venv"


def logs_dir() -> Path:
    return meta_dir() / "logs"


def lab_overrides_path() -> Path:
    """JupyterLab reads this at server start; it sets defaults the student
    can still change in Settings."""
    return venv_dir() / "share" / "jupyter" / "lab" / "settings" / "overrides.json"


# Save every few seconds instead of JupyterLab's 120 s default — a closed
# laptop lid must not cost a student their last two minutes of work.
LAB_OVERRIDES = {
    "@jupyterlab/docmanager-extension:plugin": {"autosave": True, "autosaveInterval": 3},
}


def write_lab_overrides() -> Path:
    path = lab_overrides_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(LAB_OVERRIDES, indent=2) + "\n", encoding="utf-8")
    return path


def venv_python() -> Path:
    venv = venv_dir()
    return venv / ("Scripts/python.exe" if sys.platform == "win32" else "bin/python")


def venv_jupyter() -> Path:
    venv = venv_dir()
    return venv / ("Scripts/jupyter.exe" if sys.platform == "win32" else "bin/jupyter")


def load_config() -> dict:
    path = config_path()
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}


def save_config(config: dict) -> None:
    path = config_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(config, indent=2, ensure_ascii=False), encoding="utf-8")
    try:
        path.chmod(stat.S_IRUSR | stat.S_IWUSR)
    except OSError:
        pass  # Windows ACLs differ; best-effort 600


def ensure_dirs() -> None:
    for directory in (workdir(), meta_dir(), logs_dir()):
        directory.mkdir(parents=True, exist_ok=True)


def ensure_token(config: dict) -> str:
    """The pairing token is generated once and reused so `up` stays idempotent."""
    if not config.get("token"):
        config["token"] = secrets.token_urlsafe(32)
    return config["token"]


def is_apple_silicon() -> bool:
    import platform

    return sys.platform == "darwin" and platform.machine() == "arm64"


def torch_install_args() -> list[str]:
    """CPU wheels from the PyTorch index everywhere except Apple Silicon,
    where the default PyPI wheel already supports Metal."""
    if is_apple_silicon():
        return ["torch"]
    return ["torch", "--index-url", TORCH_INDEX]
