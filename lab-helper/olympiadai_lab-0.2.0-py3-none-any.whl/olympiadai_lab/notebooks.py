"""`olympiadai-lab open <url>` — fetch a practice notebook into the work dir
and print the JupyterLab URL for it. Optional datasets declared in
``metadata.olympiadai.datasets`` are downloaded next to the notebook and
verified against their sha256."""

from __future__ import annotations

import hashlib
import json
import re
import urllib.request
from pathlib import Path

from . import core


def slugify(text: str) -> str:
    slug = re.sub(r"[^a-z0-9]+", "-", text.lower()).strip("-")
    return slug[:60].strip("-") or "notebook"


def notebook_slug(notebook: dict, fallback: str) -> str:
    meta = (notebook.get("metadata") or {}).get("olympiadai") or {}
    slug = meta.get("slug")
    if isinstance(slug, str) and re.fullmatch(r"[a-z0-9][a-z0-9-]{0,80}", slug):
        return slug
    return slugify(fallback)


def fetch_json(url: str, urlopen=urllib.request.urlopen) -> dict:
    with urlopen(url, timeout=30) as response:
        return json.loads(response.read().decode("utf-8"))


def filename_from_url(url: str, default: str = "notebook.ipynb") -> str:
    path = url.split("?")[0].rstrip("/")
    if path.endswith("/content"):  # the JSON twin route — strip the suffix
        path = path[: -len("/content")]
    name = path.rsplit("/", 1)[-1]
    return name if name.endswith(".ipynb") else default


def fetch_dataset(dataset: dict, dest_dir: Path, urlopen=urllib.request.urlopen) -> Path:
    url, filename = dataset.get("url"), dataset.get("filename")
    if not url or not filename or "/" in filename or filename.startswith("."):
        raise SystemExit(f"Некорректная запись о датасете: {dataset!r}")
    dest_dir.mkdir(parents=True, exist_ok=True)
    dest = dest_dir / filename
    expected = (dataset.get("sha256") or "").lower()
    if dest.exists() and expected:
        if hashlib.sha256(dest.read_bytes()).hexdigest() == expected:
            return dest
    with urlopen(url, timeout=120) as response:
        data = response.read()
    if expected and hashlib.sha256(data).hexdigest() != expected:
        raise SystemExit(f"Контрольная сумма датасета {filename} не совпадает — файл не сохранён.")
    dest.write_bytes(data)
    return dest


def open_notebook(url: str, config: dict, urlopen=urllib.request.urlopen) -> str:
    """Idempotent: an existing notebook file is kept (student edits win)."""
    notebook = fetch_json(url, urlopen)
    filename = filename_from_url(url)
    slug = notebook_slug(notebook, filename.removesuffix(".ipynb"))
    dest_dir = core.workdir() / slug
    dest_dir.mkdir(parents=True, exist_ok=True)
    dest = dest_dir / filename
    if not dest.exists():
        dest.write_text(json.dumps(notebook, ensure_ascii=False, indent=1), encoding="utf-8")
    for dataset in (notebook.get("metadata") or {}).get("olympiadai", {}).get("datasets", []):
        fetch_dataset(dataset, dest_dir, urlopen)
    port = config.get("port", core.DEFAULT_PORT)
    token = config.get("token", "")
    return f"http://127.0.0.1:{port}/lab/tree/{slug}/{filename}?token={token}"
