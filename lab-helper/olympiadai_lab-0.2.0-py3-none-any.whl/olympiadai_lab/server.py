"""Managed venv, port selection, and the JupyterLab process lifecycle."""

from __future__ import annotations

import os
import socket
import subprocess
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

from . import core


def ensure_venv(run=subprocess.run) -> Path:
    """Create the managed venv + heavy deps once; idempotent afterwards."""
    python = core.venv_python()
    if not python.exists():
        core.ensure_dirs()
        run([sys.executable, "-m", "venv", str(core.venv_dir())], check=True)
    probe = run(
        [str(python), "-c", "import jupyterlab, numpy, pandas, sklearn, scipy, torch"],
        capture_output=True,
    )
    if probe.returncode != 0:
        pip = [str(python), "-m", "pip", "install", "--quiet"]
        run(pip + ["--upgrade", "pip"], check=True)
        run(pip + core.BASE_PACKAGES, check=True)
        run(pip + core.torch_install_args(), check=True)
    core.write_lab_overrides()   # idempotent: keeps the settings current after helper upgrades
    return python


def find_port(preferred: int = core.DEFAULT_PORT) -> int:
    """First free loopback port at or above `preferred`, up to the ceiling."""
    for port in range(preferred, core.PORT_CEILING + 1):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            try:
                # Without REUSEADDR a port the previous server just closed stays
                # unbindable while its connections sit in TIME_WAIT (~60 s), so
                # `down` + `up` would silently jump ports and break pairing.
                sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                sock.bind(("127.0.0.1", port))
                return port
            except OSError:
                continue
    raise SystemExit(f"Нет свободного порта в диапазоне {preferred}–{core.PORT_CEILING}.")


def cross_site(origin: str) -> bool:
    """True unless the LMS itself is served from 127.0.0.1 — then the lab iframe
    is same-site and Jupyter's default SameSite=Lax cookies already work."""
    from urllib.parse import urlsplit

    return urlsplit(origin).hostname != "127.0.0.1"


def jupyter_command(port: int, token: str, origin: str) -> list[str]:
    """The exact server flags — 127.0.0.1 only, token required, CORS pinned
    to the LMS origin, XSRF on, CSP allows framing by the LMS only.

    When the LMS lives on another site (a real domain, or ``localhost`` vs
    ``127.0.0.1``) the lab is a third-party iframe, and browsers drop Lax
    cookies there — the embedded lab would bounce to /login. SameSite=None
    needs Secure, which Chrome and Firefox accept from the loopback address
    even over http. Safari does not; the page falls back to a new tab."""
    settings: dict = {"headers": {"Content-Security-Policy": f"frame-ancestors 'self' {origin}"}}
    command = [
        str(core.venv_jupyter()), "lab", "--no-browser",
        "--ServerApp.ip=127.0.0.1",
        f"--ServerApp.port={port}",
        f"--ServerApp.root_dir={core.workdir()}",
        f"--ServerApp.token={token}",
        f"--ServerApp.allow_origin={origin}",
        "--ServerApp.allow_credentials=False",
        "--ServerApp.disable_check_xsrf=False",
        "--LabApp.collaborative=False",
    ]
    if cross_site(origin):
        cookie = {"samesite": "None", "secure": True}
        settings["xsrf_cookie_kwargs"] = cookie
        command.append("--IdentityProvider.cookie_options=" + repr(cookie))
    # traitlets parses Dict flags with ast.literal_eval — Python literals, not
    # JSON (`true` would silently turn the value into a list and abort startup).
    command.append("--ServerApp.tornado_settings=" + repr(settings))
    return command


def api_status(port: int, timeout: float = 2.0) -> bool:
    """True when the local Jupyter answers — 401 still proves a live server."""
    try:
        urllib.request.urlopen(f"http://127.0.0.1:{port}/api/status", timeout=timeout)
        return True
    except urllib.error.HTTPError as error:
        return error.code in (200, 401, 403)
    except OSError:
        return False


def wait_ready(port: int, timeout: float = 60.0) -> bool:
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if api_status(port):
            return True
        time.sleep(0.5)
    return False


def wait_stopped(port: int | None, timeout: float = 15.0) -> bool:
    """After SIGTERM Jupyter needs a moment to release the port; without this
    the restart would pick the next port and silently break the pairing."""
    if not port:
        return True
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if not api_status(port, timeout=0.5):
            return True
        time.sleep(0.3)
    return False


def running_pid(config: dict) -> int | None:
    pid = config.get("pid")
    if not pid:
        return None
    if sys.platform == "win32":
        probe = subprocess.run(["tasklist", "/FI", f"PID eq {pid}"], capture_output=True, text=True)
        return pid if str(pid) in probe.stdout else None
    try:
        os.kill(pid, 0)
        return pid
    except OSError:
        return None


def start(port: int, token: str, origin: str, popen=subprocess.Popen) -> int:
    """Detach a `jupyter lab` process; logs under .olympiadai/logs/."""
    core.logs_dir().mkdir(parents=True, exist_ok=True)
    log = open(core.logs_dir() / f"jupyter-{port}.log", "a", encoding="utf-8")
    command = jupyter_command(port, token, origin)
    if sys.platform == "win32":
        # DETACHED alone still dies with the caller's Job object (e.g. when the
        # terminal that ran `up` closes) — BREAKAWAY releases it from the Job.
        flags = (subprocess.CREATE_NEW_PROCESS_GROUP | subprocess.DETACHED_PROCESS
                 | getattr(subprocess, "CREATE_BREAKAWAY_FROM_JOB", 0))
        proc = popen(command, stdout=log, stderr=subprocess.STDOUT, creationflags=flags)
    else:
        proc = popen(command, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
    return proc.pid


def stop(config: dict) -> bool:
    pid = running_pid(config)
    if not pid:
        return False
    if sys.platform == "win32":
        subprocess.run(["taskkill", "/PID", str(pid), "/T", "/F"], capture_output=True)
    else:
        try:
            os.kill(pid, 15)  # SIGTERM; jupyter exits cleanly
        except OSError:
            return False
    return True
